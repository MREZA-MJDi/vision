VISION FITTING-ROOM ASSET IMPORT PACKAGE

This package preserves the exact archive path expected by the VISION branch seeder.

1. Extract this package at the root of a checkout of MREZA-MJDi/vision on branch
   feature/vision-fitting-room-redesign.
2. Commit database/seeders/assets/vision-fitting-room-assets.zip to the branch.
3. Deploy the branch and run:
     php artisan migrate --force
     php artisan db:seed --class=FittingRoomAssetSeeder --force

The seeder copies the 46 WebP assets to the public storage disk and creates persistent
media records, catalog variant gallery links, the default mannequin, 12 looks, scene
references, and product-variant slot mappings. The database seeder is idempotent.

Alternative to committing the nested archive: place vision-fitting-room-assets.zip at
storage/app/seed-imports/vision-fitting-room-assets.zip on the server before running
FittingRoomAssetSeeder.
